import cv2
import numpy as np

def treinar_reconhecedor(imagens_treino, etiquetas):
    """
    Treina o LBPH usando as imagens fornecidas e etiquetas.
    """
    reconhecedor = cv2.face.LBPHFaceRecognizer_create()
    reconhecedor.train(imagens_treino, np.array(etiquetas))
    return reconhecedor

def reconhecer_rosto(reconhecedor, imagem_teste):
    """
    Reconhece a cara com a imagem fornecida e retorna a etiqueta prevista e confiança.
    """
    cinzento = cv2.cvtColor(imagem_teste, cv2.COLOR_BGR2GRAY)  # Converte para cinzento
    etiqueta, confianca = reconhecedor.predict(cinzento)  # Predição
    return etiqueta, confianca
