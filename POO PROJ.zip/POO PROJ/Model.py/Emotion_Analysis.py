from deepface import DeepFace

def analisar_emocao(caminho_imagem):
    """
    Analisa a emoção dada na imagem e retorna a emoção dominante e nível de confiança.
    """
    resultado = DeepFace.analyze(img_path=caminho_imagem, actions=['emotion'], enforce_detection=False)
    emocao = resultado['dominant_emotion']
    confianca = resultado['emotion'][emocao]
    return emocao, confianca
