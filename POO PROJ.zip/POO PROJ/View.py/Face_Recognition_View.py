from PySide6.QtCore import QCoreApplication, QMetaObject, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QDialog, QPushButton, QFileDialog, QLabel, QVBoxLayout

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(826, 600)
        
        self.botao_procura_imagem = QPushButton(Dialog)
        self.botao_procura_imagem.setObjectName(u"botao_procura_imagem")
        self.botao_procura_imagem.setGeometry(40, 60, 141, 29)
        self.botao_procura_imagem.setText("Procurar Imagem")
        
        self.botao_reconhecer = QPushButton(Dialog)
        self.botao_reconhecer.setObjectName(u"botao_reconhecer")
        self.botao_reconhecer.setGeometry(240, 60, 88, 29)
        self.botao_reconhecer.setText("Reconhecer")
        
        self.botao_ruido_aleatorio = QPushButton(Dialog)
        self.botao_ruido_aleatorio.setObjectName(u"botao_ruido_aleatorio")
        self.botao_ruido_aleatorio.setGeometry(367, 60, 121, 29)
        self.botao_ruido_aleatorio.setText("Ruído Aleatório")
        
        self.botao_pixelar = QPushButton(Dialog)
        self.botao_pixelar.setObjectName(u"botao_pixelar")
        self.botao_pixelar.setGeometry(367, 20, 121, 29)
        self.botao_pixelar.setText("Pixelar")
        
        self.slider_horizontal = QSlider(Dialog)
        self.slider_horizontal.setObjectName(u"slider_horizontal")
        self.slider_horizontal.setGeometry(520, 70, 160, 16)
        self.slider_horizontal.setMaximum(100)
        self.slider_horizontal.setValue(1)
        
        self.widget = QWidget(Dialog)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(70, 119, 631, 381)

        self.retranslateUi(Dialog)
        QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Reconhecimento de Rosto", None))

class Dialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.controller = controller

        self.ui.botao_procura_imagem.clicked.connect(self.browse_file)
        self.ui.botao_reconhecer.clicked.connect(self.reconhecer_rosto)

    def browse_file(self):
        """
        Open a file dialog to browse and select an image.
        """
        file_dialog = QFileDialog(self)
        file_path, _ = file_dialog.getOpenFileName()
        if file_path:
            self.process_image(file_path)

    def process_image(self, file_path):
        """
        Process the image for face recognition and emotion analysis.
        """
        # Chama os métodos para analizar emoções e reconhecer a cara.
        try:
            emotion, confidence = self.controller.analisar_emocao(file_path)
            self.show_emotion(emotion, confidence)
        except Exception as e:
            self.show_error(f"Error analyzing emotion: {str(e)}")

        try:
            face_label, face_confidence = self.controller.reconhecer(file_path)
            self.show_face_result(face_label, face_confidence)
        except Exception as e:
            self.show_error(f"Error recognizing face: {str(e)}")

    def show_emotion(self, emotion, confidence):
        """
        Show the detected emotion and confidence level.
        """
        print(f"Emotion: {emotion}, Confidence: {confidence}")

    def show_face_result(self, face_label, confidence):
        """
        Show the recognized face label and confidence.
        """
        print(f"Face Label: {face_label}, Confidence: {confidence}")

    def show_error(self, message):
        """
        Display error message.
        """
        print(f"Error: {message}")
