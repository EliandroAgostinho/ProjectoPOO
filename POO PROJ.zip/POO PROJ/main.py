import sys
from PySide6.QtWidgets import QApplication
from model.Face_Recognition_Handler import treinar_reconhecedor
from controller.Face_recognition_controller import Controller
from view.Face_Recognition_View import Dialog

if __name__ == "__main__":
    # Initialize the controller
    controller = Controller()

    # For testing, you can train the model here (make sure you have training data)
    # Example: controller.treinar_modelo(training_images, labels)

    app = QApplication(sys.argv)
    widget = Dialog(controller)
    widget.show()
    sys.exit(app.exec())
