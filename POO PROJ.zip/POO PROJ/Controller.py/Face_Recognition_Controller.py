from model.Face_Recognition_Handler import treinar_reconhecedor, reconhecer_rosto
from model.Emotion_Analysis import analisar_emocao
import cv2

class Controller:
    def __init__(self):
        self.modelo_lbph = None

    def treinar_modelo(self, imagens_treino, etiquetas):
        """
        Train the LBPH recognizer using training images and labels.
        """
        self.modelo_lbph = treinar_reconhecedor(imagens_treino, etiquetas)

    def reconhecer(self, imagem_teste):
        """
        Recognize a face in the test image.
        """
        if not self.modelo_lbph:
            raise ValueError("The model is not trained yet.")
        etiqueta, confianca = reconhecer_rosto(self.modelo_lbph, imagem_teste)
        if confianca > 100:  # Adjust threshold based on your model's confidence levels
            raise ValueError("Face not recognized with enough confidence.")
        return etiqueta, confianca

    def analisar_emocao(self, caminho_imagem_teste):
        """
        Analyze the emotion in the test image.
        """
        return analisar_emocao(caminho_imagem_teste)
